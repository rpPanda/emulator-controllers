# stf-binaries
Repo to place STF binaries

- npm <https://www.npmjs.com/package/minicap-prebuilt>
- github <https://github.com/openstf/minicap>

## How to update
```
npm outdated # show outdated package
npm update # update all deps
```